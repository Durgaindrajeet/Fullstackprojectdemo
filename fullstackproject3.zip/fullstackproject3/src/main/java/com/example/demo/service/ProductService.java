package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Product;

public interface ProductService {
	public List<Product> getProduct();
	public Product getProductById(Long pid);
	public Product getProductByName(String pname);
	public Product postProduct(Product product);
	public String deleteProductById(Long pid);
	public String UpdateProduct(Long pid, Product updatingproduct);
}
