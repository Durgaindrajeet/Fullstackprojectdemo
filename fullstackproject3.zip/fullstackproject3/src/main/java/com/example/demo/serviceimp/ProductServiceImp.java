package com.example.demo.serviceimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;

@Service
public class ProductServiceImp implements ProductService {
	
	@Autowired
	ProductRepository productrepo;

	public List<Product> getProduct() {
		
		return productrepo.findAll();
	}

	public Product getProductById(Long pid) {
		
	Optional<Product> product= productrepo.findById(pid);
		// TODO Auto-generated method stub
		return product.orElse(null);
	}

	public Product getProductByName(String pname) {
		Product product = productrepo.findByName(pname);
		// TODO Auto-generated method stub
		return product;
	}

	public Product postProduct(Product product) {
	Product s	= productrepo.save(product);
		// TODO Auto-generated method stub
		return s;
	}

	public String deleteProductById(Long pid) {
		productrepo.deleteById(pid);
		// TODO Auto-generated method stub
		return "Delete Success";
	}

	public String UpdateProduct(Long pid, Product updatingproduct) {
		// get the record from db
		 Optional<Product> existingproduct = productrepo.findById(pid);
		 
		 if(existingproduct.isPresent()) {
			 
			 //modify in app layer
			 Product product = existingproduct.get();
			 product.setPname(updatingproduct.getPname());
			 
			 //save the updated record
			 productrepo.save(product);
			 
			 return "update sucess";
			 
		 }
					 
			 else {
				 return "RECORD NOT FOUND";
			 }
		 }
	}
		
		
	
	
	


