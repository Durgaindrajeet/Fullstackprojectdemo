package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.serviceimp.ProductServiceImp;

@RestController
public class ProductController {
	@Autowired
	ProductServiceImp productserviceimp;
	
	//get the list of product
	@GetMapping (value = "/getpro")
	public List<Product>getProduct(){
		return productserviceimp.getProduct();		
	}
	//get the product by id
	@GetMapping (value ="/getproid/{pid}")
	public Product getProductById(@PathVariable Long pid){ 
		return productserviceimp.getProductById(pid);		
	}
	
	//get the product by name
	@GetMapping (value = "/getproname/{pname}")
	public Product getProductByName(@PathVariable String pname){ 
		return productserviceimp.getProductByName(pname);		
	}
	
	//insert into product
	@PostMapping (value = "/postpro")
	public Product postProduct(@RequestBody Product product){ 
		return productserviceimp.postProduct(product);		
	}
	
	// delete product by id
		@DeleteMapping (value = "/deletepro/{pid}")
		public String deleteProductById(@PathVariable Long pid){ 
			return productserviceimp.deleteProductById(pid);		
		}
		
		//update product by id
		@PutMapping (value = "/putpro/{pid}")
		public String updateProduct(@PathVariable Long pid,@RequestBody Product product){ 
			return productserviceimp.UpdateProduct(pid,product);		
		}
}
